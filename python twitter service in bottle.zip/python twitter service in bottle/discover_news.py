import sys
import requests
import json
import operator
import twitter
import bottle
import os
from bottle import post, get, run, request, response, route, static_file, error, HTTPError
import watson_developer_cloud
username = os.environ.get('4437d062-9bc7-44d6-bec6-984a4a3b2d7e', None)
password = os.environ.get('gJOj1QMzQwYs', None)
# environment_id = os.environ.get('9ba990cd-1537-4109-ba74-7a8b186f8f8b', None)
# collection_id = os.environ.get('790a48ce-ae4b-42b0-99e5-54d2492268dc', None)
# https://gateway.watsonplatform.net/discovery/api/v1/environments/9ba990cd-1537-4109-ba74-7a8b186f8f8b/collections/790a48ce-ae4b-42b0-99e5-54d2492268dc/query?version=2016-11-07&query=genpact&count=7&offset=&aggregation=&filter=&passages=false&return=
endpoint = "https://gateway.watsonplatform.net/discovery/api/v1/environments/9ba990cd-1537-4109-ba74-7a8b186f8f8b/collections/790a48ce-ae4b-42b0-99e5-54d2492268dc/query?version=2016-11-07&"
#-----------------------------------------------------------------------
def enable_cors(decoratorfn):
   """
   Cross Origin Resource Sharing
   :param decoratorfn:
   :return:
   """

   def _enable_cors(*args, **kwargs):
       """
       :param args:
       :param kwargs:
       :return:
       """
       # set CORS headers
       response.headers['Access-Control-Allow-Origin'] = '*'
       response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, OPTIONS'
       response.headers['Access-Control-Allow-Headers'] = 'Origin, Accept, ' \
                                                          'Content-Type, X-Requested-With, ' \
                                                          'X-CSRF-Token'
       response.headers['Content-Type'] = 'application/json'
       if request.method != 'OPTIONS':
           return decoratorfn(*args, **kwargs)

   return _enable_cors


@post('/newHeadlines')
@enable_cors
def newHeadlines():
    combo = request.json['combo']
    comboWords=combo.replace("\"","").split('|')

    combos=[]
    headlines={}


    try:
        get_url = endpoint+"query=title:("+combo+")|enrichedTitle.entities.text:("+combo+")&count=50&return=text,url"
        results = requests.get(url=get_url, auth=('4437d062-9bc7-44d6-bec6-984a4a3b2d7e', 'gJOj1QMzQwYs'))
        response = results.json()
        print(response)


        for article in response['results']:
            combos[:]=[]
            for word in comboWords:
                if word.upper() in article['text'].upper():
                    combos.append(word)
            comboStr = ''.join(sorted(combos))
            comboLen = len(combos)
            if comboLen not in headlines:
                headlines[comboLen]={}
            if comboStr not in headlines[comboLen]:
                headlines[comboLen][comboStr]={}
            headlines[comboLen][comboStr][article['text']]=article['url']


    except Exception as e:
        print e
    output = { 'headlines': headlines }
    print(output)

    return json.dumps(output)
#-------------------------------------------------------------------------------
run(host="127.0.0.1", port="8080",debug=True,reloader=True)
