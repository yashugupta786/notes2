import sys
import requests
import json
import operator
import twitter
import bottle
from bottle import post, get, run, request, response, route, static_file, error, HTTPError
from watson_developer_cloud import PersonalityInsightsV2 as PersonalityInsights


# -------------------------------------------------------------------------------------------------#
def enable_cors(decoratorfn):
   """
   Cross Origin Resource Sharing
   :param decoratorfn:
   :return:
   """

   def _enable_cors(*args, **kwargs):
       """
       :param args:
       :param kwargs:
       :return:
       """
       # set CORS headers
       response.headers['Access-Control-Allow-Origin'] = '*'
       response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, OPTIONS'
       response.headers['Access-Control-Allow-Headers'] = 'Origin, Accept, ' \
                                                          'Content-Type, X-Requested-With, ' \
                                                          'X-CSRF-Token'
       response.headers['Content-Type'] = 'application/json'
       if request.method != 'OPTIONS':
           return decoratorfn(*args, **kwargs)

   return _enable_cors


# -------------------------------------------------------------------------------------------------#
# This function is used to receive and analyze
# the last 200 tweets of a Twitter handle using
# the Watson PI API
def analyze(handle):
   # The Twitter API credentials
   twitter_consumer_key = 'c57iiY5USiBlq3PZ8DjHHvjYQ'
   twitter_consumer_secret = 'g5Caq9kvqNG0hxAedQw7ififCshmyGFXgmxd69YazsRExl7eoN'
   twitter_access_token = '120760682-lBhvUfggi2sY6FDJoYqIiOkq4wOAQWdnAB2rGKNB'
   twitter_access_secret = 'fUhkxzLCv5X5IxFjZ7cSP9xfrsETCg4YvtXee6tadzJAL'

   # Invoking the Twitter API
   twitter_api = twitter.Api(consumer_key=twitter_consumer_key,
                             consumer_secret=twitter_consumer_secret,
                             access_token_key=twitter_access_token,
                             access_token_secret=twitter_access_secret)

   # Retrieving the last 200 tweets from a user
   statuses = twitter_api.GetUserTimeline(screen_name=handle, count=200, include_rts=False)


   # Putting all 200 tweets into one large string called "text"
   text = ""
   for s in statuses:
       if (s.lang == 'en'):
           text += s.text

   print (text)




           # Analyzing the 200 tweets with the Watson PI API
   pi_result = PersonalityInsights(username='37b43eb0-2ed8-486d-a65a-82a1b11ccc18', password='UyJ7aqqveZcS').profile(
       text)
   # print(pi_result)
   # bog=json.dumps(pi_result)
   # yy=eval(bog)
   #
   # return yy





   # print "all_result",pi_result

   # for keys, value in pi_result.iteritems():


   # Returning the Watson PI API results
   return pi_result


# This function is used to flatten the result
# from the Watson PI API
def flatten(orig):
   data = {}

   # for c in orig['tree']['children']:
   #     if 'children' in c:
   #         for c2 in c['children']:
   #             if 'children' in c2:
   #                 for c3 in c2['children']:
   #                     if 'children' in c3:
   #                         for c4 in c3['children']:
   #                             if (c4['category'] == 'personality'):
   #                                 data[c4['id']] = c4['percentage']
   #                                 if 'children' not in c3:
   #                                     if (c3['category'] == 'personality'):
   #                                         data[c3['id']] = c3['percentage']
   # return data
   #

# This function is used to compare the results from
# the Watson PI API
# def compare(dict1):
#    compared_data = {}
#    for keys in dict1:
#        compared_data[keys] = abs(dict1[keys])
#    return compared_data

# -------------------------------------------------------------------------------------------------#
@post("/getPersonalityInsights")
@enable_cors
def get_personality_insight():
   final_dict = dict()
   insight_list = []
   json_req = dict(request.json)
   print('Json extracted from the ui end ',type (json_req))
   user_handle = json_req["user_handle"]

   # The two Twitter handles
   # user_handle = "@tyagarajan"
   # celebrity_handle = "@IBM"

   # Analyze the user's tweets using the Watson PI API
   user_result = analyze(user_handle)
   return user_result
   # celebrity_result = analyze(celebrity_handle)

#    # Flatten the results received from the Watson PI API
#    user = flatten(user_result)
#    print (user)
#    # for key, value in user.iteritems():
#    #     print key
#    #     print value
#
#    # celebrity = flatten(celebrity_result)
#
#    # Compare the results of the Watson PI API by calculating
#    # the distance between traits
#
#
#    # Sort the results
#    # sorted_results = sorted(compared_results.items(), key=operator.itemgetter(1))
#    # print ("results in sorted form " ,sorted_results)
#    # print('sorted_Results',type(sorted_results))
#    # boggu={}
#
#
#    for keys, value in user.iteritems():
#        temp_dict = dict()
#        # print keys
#        # if keys["Imagination"]:
#        #     boggu["name"]="Imagination"
#        #     boggu["percentile"]=
#
#
#        # print("allvalue",value)
#        temp_dict["percentile"] = value
#        temp_dict["name"] = keys
#        temp_dict["category"] ="personality"
#
#        insight_list.append(temp_dict)
#        # # print (user[keys]),
#        # print ('->'),
#        # # print (celebrity[keys]),
#        # # print ('->'),
#        # print (compared_results[keys])
#
#    final_dict["insights"] = insight_list
#
#    print final_dict
#    return final_dict
#
#
# # -------------------------------------------------------------------------------------------------#


@enable_cors
@error(404)
def error404(error1):
   """
   Method captures the error messages for code 404
   :param error1: Error Code
   :return: Error message
   """
   response.content_type = 'application/json'
   return json.dumps({'message': 'Sorry there is nothing here'})


# -------------------------------------------------------------------------------------------------#
@enable_cors
@error(500)
def error500(error1):
   """
   Method captures the error messages for code 500
   :param error1: Error Code
   :return: Error message
   """
   response.content_type = 'application/json'
   return json.dumps({
       'message': 'There was Processing problem make sure your request type is POST '
                  'and has Content-Type:application/json in header'})


# -------------------------------------------------------------------------------------------------#
@enable_cors
@error(428)
def error428(error1):
   """
   Method captures the error messages for code 428
   :param error1: Error Code
   :return: Error message
   """
   response.content_type = 'application/json'
   return json.dumps({'message': 'Improper json Structure or Json key missing'})


# -------------------------------------------------------------------------------------------------#
@route("/")
def index():
   """
   Need to Fill in the docstring
   :return:
   """
   return static_file('index.html', root='./static')


# -------------------------------------------------------------------------------------------------#
@route('/static/<filepath:path>')
def server_static(file_path):
   """
   Need to Fill in the docstring
   :param file_path:
   :return:
   """
   return static_file(file_path, root='./static')


# -------------------------------------------------------------------------------------------------#

run(host="0.0.0.0", port="8080",debug=True,reloader=True)

